function Animation(span){
    this.span = span*1000;
}